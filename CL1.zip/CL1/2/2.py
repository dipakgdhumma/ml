import pandas as pd
import numpy as np
import seaborn as sns
from geopy.distance import great_circle
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.metrics import r2_score, mean_squared_error

file = './2/uber.csv'
data = pd.read_csv(file)

data['pickup_datetime'] = pd.to_datetime(data['pickup_datetime'], errors='coerce')
data['hour'] = data['pickup_datetime'].dt.hour
data['day'] = data['pickup_datetime'].dt.day
data['month'] = data['pickup_datetime'].dt.month

data = data(data['pickup_latitude'].between(-90, 90)&
            data['dropoff_latitude'].between(-90, 90)&
            data['pickup_longitude'].between(-180, 180)&
            data['dropoff_longitude'].between(-180, 180))

def cal_dis(row):
    pickup = (row['pickup_latitude'], row['pickup_longitude'])
    dropoff = (row['dropff_latitude'], row['dropoff_longitude'])
    try:
        return great_circle(pickup, dropoff).km
    except:
        return np.nan
    
data['distance'] = data.apply(cal_dis, axis=1)

data.dropna(subset['distance'], inplace=True)
data = data[(data['fare_amount']>0)&(data['distance']>0)&(data['distance']<200)]

q1 = data['fare_amount'].quantile(0.25)
q3 = data['fare_amount'].quantile(0.75)
iqr = q3-q1
low = q1-1.5*iqr
upp = q3+1.5*iqr

data = data[(data['fare_amount']>=low)&(data['fare_amount']<=upp)]

plt.figure(figsize=(8, 6))
sns.heatmap(data[['fare_amount', 'distance', 'passenger_count', 'hour', 'day', 'month']].corr(), annot=True, cmap='coolwarm')
plt.title("correlateion Heatmap")
plt.show()

x=data[['distance', 'passenger_count', 'hour', 'day', 'month']]
y=data['fare_amount']

xtr, xte, ytr, yte = train_test_split(x, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
xtr = scaler.fit_transform(xtr)
xte = scaler.transform(xte)

lr = LinearRegression()
rg = Ridge(alpha=1.0)
ls = Lasso(alpha=1.0)

lr.fit(xtr, ytr)
rg.fit(xtr, ytr)
ls.fit(xtr, ytr)

def evaluate(model, name):
    ypred = model.predict(xte)
    r2 = r2_score(yte, ypred)
    rmse = np.sqrt(mean_squared_error(yte, ypred))
    