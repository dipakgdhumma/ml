import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import requests

API_KEY = "bcc022f397c910d58d237f3240a3d9b2"
City = "Pune"
URL = f"https://api.openweathermap.org/data/2.5/forecast?q={City}&appid={API_KEY}&units=metric"

response = requests.get(URL)
data = response.json()

records = []
for item in data['list']:
    dt = datetime.fromtimestamp(item['dt'])
    temp = item['main']['temp']
    humidity = item['main']['humidity']
    wind_speed = item['wind']['speed']
    weather = item['weather'][0]['main']
    records.append({
        "Datetime": dt,
        "Temperature": temp,
        "Humidity": humidity,
        "Wind Speed": wind_speed,
        "condition": weather
    })
    
df = pd.DataFrame(records)

df = df.drop_duplicates()
df = df.dropna()

print("Avg Temp: ", df['Temperature'].mean())
print("max Temp: ", df['Temperature'].max())
print("min Temp: ", df['Temperature'].min())

plt.figure(figsize=(10, 5))
plt.plot(df["Datetime"], df['Temperature'], marker='o')
plt.show()

plt.figure(figsize=(5, 4))
sns.heatmap(df[["Temperature", "Humidity", "Wind Speed"]].corr(), annot=True, cmap="coolwarm")
plt.title("Correlation between weather attributes")
plt.show()

df['Date'] = df['Datetime'].dt.date
daily_avg = df.groupby('Date')[["Temperature", 'Humidity']].mean().reset_index()
print(daily_avg)

plt.figure(figsize=(10,5))
plt.plot(daily_avg['Date'], daily_avg['Temperature'], label='Avg Temp', marker='o')
plt.plot(daily_avg['Date'], daily_avg['Humidity'], label='Avg Humidity', marker='s')
plt.title(f"Daily Weather Summary in {City}")
plt.xlabel("Date")
plt.ylabel("Values")
plt.legend()
plt.show()