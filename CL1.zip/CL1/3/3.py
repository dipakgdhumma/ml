from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.svm import SVC
import seaborn as sns
import matplotlib.pyplot as plt

import random

digits = datasets.load_digits()
x, y = digits.data, digits.target

for i in random.sample(range(len(digits.images)), 5):
    plt.imshow(digits.images[i], cmap='grey')
    plt.title(digits.target[i])
    plt.axis('off')
    plt.show()
    
xtr, xte, ytr, yte = train_test_split(x, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
xtr = scaler.fit_transform(xtr)
xte = scaler.transform(xte)

model = SVC(kernel='rbf', gamma=0.001, C=10)
model.fit(xtr, ytr)

ypre = model.predict(xte)
cm = confusion_matrix(ypre, yte)
sns.heatmap(cm, annot=True, cmap='Blues', fmt='d')
plt.xlabel("Pred")
plt.ylabel("Act")
plt.show()

