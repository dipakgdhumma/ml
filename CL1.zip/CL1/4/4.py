# ===== K-Means Clustering on Iris Dataset =====

# Step 1: Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Step 2: Load dataset
url = "./4/Iris.csv"
data = pd.read_csv(url)
print("Dataset loaded successfully!")
print(data.head())

# Step 3: Preprocess data (remove species for unsupervised learning)
X = data.drop('Species', axis=1)

# Step 4: Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 5: Use Elbow Method to find optimal K
wcss = []
K_range = range(1, 11)
for k in K_range:
    kmeans = KMeans(n_clusters=k, init='k-means++', random_state=42)
    kmeans.fit(X_scaled)
    wcss.append(kmeans.inertia_)  # inertia = WCSS

plt.plot(K_range, wcss, marker='o')
plt.title('Elbow Method for Optimal K')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('WCSS')
plt.show()

# Step 6: Apply K-Means with optimal K (usually 3 for Iris)
kmeans = KMeans(n_clusters=3, init='k-means++', random_state=42)
y_kmeans = kmeans.fit_predict(X_scaled)

# Step 7: Add cluster labels to dataset
data['Cluster'] = y_kmeans

# Step 8: Visualize clusters (using first 2 features)
plt.figure(figsize=(8,6))
sns.scatterplot(x=X_scaled[:, 0], y=X_scaled[:, 1], hue=y_kmeans)
plt.title('K-Means Clusters (using first 2 features)')
plt.xlabel('Sepal Length (scaled)')
plt.ylabel('Sepal Width (scaled)')
plt.show()

# Step 9: Display cluster centroids
print("\nCluster Centroids (in scaled feature space):")
print(kmeans.cluster_centers_)
