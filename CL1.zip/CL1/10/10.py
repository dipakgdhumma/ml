import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns 

df = pd.read_csv('./10/Housing.csv')
print(df.shape)

df.columns = df.columns.str.lower().str.strip().str.replace(' ', " ")

df.isnull().sum()

for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].fillna(df[col].mode()[0])
    else:
        df[col] = df[col].fillna(df[col].median())
        
fil_df = df[df['bedrooms']>2]
print(fil_df.shape)

# print(df.head())
df_encoded = pd.get_dummies(df, drop_first=True)
# print(df_encoded.head())

avg_price = df.groupby('furnishingstatus')['prices'].mean().reset_index()
q1 = df['price'].quantile(0.25)
q3 = df['price'].quantile(0.75)
iqr = q3-q1
low = q1 - 1.5*iqr
upp = q3 - 1.5*iqr
df=df[(df['price']>=low)&(df['price']<=upp)]
print(df.shape)

plt.figure()
sns.barplot(x='furnishingstatus', y='price', data=avg_price, palette='viridis')
plt.show()

