import pandas as pd

# -------------------------------
# 1. Load the Sales Data (CSV)
# -------------------------------
df = pd.read_csv("Sales Data.csv")

print("First 5 Rows:")
print(df.head(), "\n")

# -------------------------------
# 2. Explore Data Structure
# -------------------------------
print("Dataset Info:")
print(df.info(), "\n")

print("Missing Values per Column:")
print(df.isnull().sum(), "\n")

# -------------------------------
# 3. Data Cleaning
# -------------------------------
# Remove unnecessary column
if 'Unnamed: 0' in df.columns:
    df = df.drop('Unnamed: 0', axis=1)

# Remove duplicates
df = df.drop_duplicates()

# Convert Order Date to datetime
df['Order Date'] = pd.to_datetime(df['Order Date'])

# Check for negative or zero sales
df = df[df['Sales'] > 0]

print("Cleaned Data:")
print(df.head(), "\n")

# -------------------------------
# 4. Transformation & Analysis
# -------------------------------
# Example 1: Total Sales per City
city_sales = df.groupby('City')['Sales'].sum().reset_index().sort_values('Sales', ascending=False)
print("Total Sales by City:")
print(city_sales, "\n")

# Example 2: Most Sold Products
top_products = df.groupby('Product')['Quantity Ordered'].sum().reset_index().sort_values('Quantity Ordered', ascending=False)
print("Top 5 Products by Quantity Ordered:")
print(top_products.head(), "\n")

# Example 3: Average Order Value per Month
monthly_avg = df.groupby('Month')['Sales'].mean().reset_index()
print("Average Sales per Month:")
print(monthly_avg, "\n")

# -------------------------------
# 5. Save Cleaned Unified Data
# -------------------------------
df.to_csv("Cleaned_Sales_Data.csv", index=False)
print("Cleaned data saved as 'Cleaned_Sales_Data.csv'")
