import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

df = pd.read_csv("./9/Telco-Customer-Churn.csv")
print(df.head())
print(df.isnull().sum())

for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].fillna(df[col].mode()[0])
    else:
        df[col] = df[col].fillna(df[col].mean())
        
df = df.drop_duplicates()

for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].str.lower()
        df[col] = df[col].str.strip()
        
if 'TotalCharges' in df.columns:
    df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
    
num_col = df.select_dtypes(include=np.number).columns()
for col in num_col:
    q1 = df[col].quantile(0.25)
    q3 = df[col].quantile(0.75)
    iqr = q3-q1
    low = q1 - 1.5*iqr
    upp = q3 - 1.5*iqr
    df = df[(df[col]>=low)&(df[col]<=upp)]

df['AvgMonthlyCharges'] = df['TotalCharges']/(df['tenure'].replace(0, 1))

scaler = StandardScaler()
df[num_col] = scaler.fit_transform(df[num_col])

x = df.drop('Churn', axis=1)
y = df['Churn']

xtr, xte, ytr, yte = train_test_split(x, y, 0.2, 42)

        
