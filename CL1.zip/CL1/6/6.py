# ===== Reinforcement Learning: Maze Navigation using Q-Learning =====

import numpy as np
import random
import time
import os

# Step 1: Define the maze environment
# 0 = open path, 1 = wall, 2 = goal
maze = np.array([
    [0, 0, 1, 0, 2],
    [0, 1, 0, 0, 1],
    [0, 0, 0, 1, 0],
    [1, 0, 0, 0, 0]
])

rows, cols = maze.shape
actions = ['up', 'down', 'left', 'right']

# Step 2: Initialize Q-table
Q = np.zeros((rows, cols, len(actions)))

# Step 3: Define learning parameters
alpha = 0.7      # learning rate
gamma = 0.9      # discount factor
epsilon = 0.1    # exploration rate
episodes = 300   # number of training episodes

# Step 4: Define helper functions
def is_valid(pos):
    r, c = pos
    return 0 <= r < rows and 0 <= c < cols and maze[r, c] != 1

def get_next_state(state, action):
    r, c = state
    if action == 'up':    r -= 1
    elif action == 'down': r += 1
    elif action == 'left': c -= 1
    elif action == 'right': c += 1
    if not is_valid((r, c)):
        return state, -1   # invalid move → penalty
    if maze[r, c] == 2:
        return (r, c), 10  # goal reached → reward
    return (r, c), -0.1    # small penalty for each step

# Step 5: Train using Q-learning
for ep in range(episodes):
    state = (0, 0)  # start
    total_reward = 0
    for _ in range(100):  # limit moves per episode
        if random.uniform(0, 1) < epsilon:
            action_idx = random.randint(0, 3)  # explore
        else:
            action_idx = np.argmax(Q[state[0], state[1]])  # exploit best

        action = actions[action_idx]
        next_state, reward = get_next_state(state, action)
        total_reward += reward

        # Update Q-value
        Q[state[0], state[1], action_idx] += alpha * (reward + gamma * np.max(Q[next_state[0], next_state[1]]) - Q[state[0], state[1], action_idx])
        state = next_state
        if maze[state] == 2:  # goal reached
            break
    if (ep + 1) % 50 == 0:
        print(f"Episode {ep+1}: Total Reward = {round(total_reward, 2)}")

# Step 6: Test the trained agent
print("\nTesting trained agent...\n")
state = (0, 0)
path = [state]

for _ in range(20):
    action_idx = np.argmax(Q[state[0], state[1]])
    action = actions[action_idx]
    next_state, _ = get_next_state(state, action)
    path.append(next_state)
    state = next_state
    if maze[state] == 2:
        print("Goal Reached!")
        break

print("Path taken by the agent:")
print(path)
