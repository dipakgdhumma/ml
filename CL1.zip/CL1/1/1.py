import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

file = "./1/Wine.csv"
data = pd.read_csv(file)

X = data.drop('Customer_Segment', axis=1)
y = data['Customer_Segment']

scaler = StandardScaler()
X_Sc = scaler.fit_transform(X)

pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_Sc)

pca_df = pd.DataFrame(data=X_pca, columns=['PC1', 'PC2'])
pca_df['Customer_Segment'] = y

plt.figure(figsize=(8, 6))
for segment in pca_df['Customer_Segment'].unique():
    subset = pca_df[pca_df['Customer_Segment']==segment]
    plt.scatter(subset["PC1"], subset["PC2"], label=f"segment {segment}")
    
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("PCA on wine")
plt.legend()
plt.show()

print(pca.explained_variance_ratio_)